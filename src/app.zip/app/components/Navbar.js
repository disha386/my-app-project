"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { useState } from "react";


export default function Navbar() {

  const pathname = usePathname();
  const [openMenu, setOpenMenu] = useState(null);
  const [expertiseContent, setExpertiseContent] = useState("bim");

  const expertiseMenu = [
  "bim",
  "engineering",
  "digital",
  "twin",
  "cad",
  "verticals",
];


  return (
    <div className="w-full fixed top-0 left-0 bg-white z-50">

      {/* NAVBAR ROW */}
    <div className="flex justify-center py-6 px-10 relative z-50">

      

        {/* CENTER MENU */}
        <div className="flex gap-4 text-[15px] text-black items-center relative z-50">

          {/* ABOUT */}
          <div className="relative z-50">

            <div
              onClick={() =>
                setOpenMenu(openMenu === "about" ? null : "about")
              }
              className="cursor-pointer flex items-center gap-1"
            >
              <span className="hover:text-blue-900">About</span>

              <svg width="12" height="12" viewBox="0 0 24 24" fill="none"
                stroke="currentColor" strokeWidth="2">
                <polyline points="6 9 12 15 18 9" />
              </svg>
            </div>

            {openMenu === "about" && (
              <div className="absolute top-8 left-0 flex flex-col bg-gray-100 shadow-lg rounded-lg p-4 w-48 z-50">

                <span className="text-black py-1 hover:text-blue-900">Company</span>
                <span className="text-black py-1 hover:text-blue-900">Team</span>
                <span className="text-black py-1 hover:text-blue-900">Mission</span>
                <span className="text-black py-1 hover:text-blue-900">Vision</span>
                <span className="text-black py-1 hover:text-blue-900">Careers</span>

              </div>
            )}

          </div>
{/* OUR EXPERTISE */}
<div className="relative z-50">

  <div
    onClick={() =>
      setOpenMenu(openMenu === "expertise" ? null : "expertise")
    }
    className="cursor-pointer flex items-center gap-1"
  >
    <span className="hover:text-blue-900">Our Expertise</span>

    <svg
      width="12"
      height="12"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
    >
      <polyline points="6 9 12 15 18 9" />
    </svg>
  </div>

  {openMenu === "expertise" && (
    <div className="fixed left-0 top-[72px] w-full z-40 bg-white">

      <div className="shadow-lg w-full overflow-hidden rounded-b-3xl">

        {/* MAIN ROW (NO px-4 = fixes edge gap issue) */}
        <div className="w-full flex min-h-[380px] overflow-hidden">

          {/* LEFT BLUE SIDE */}
 <div className="bg-blue-900 text-white p-10 w-[24%] font-sans">

  

  <div className="space-y-3">

    {/* BIM */}
    <div
      onClick={() => setExpertiseContent("bim")}
      className="cursor-pointer"
    >
      <p className={`px-2 py-1 text-[17px] font-medium relative transition ${
        expertiseContent === "bim"
          ? "text-black bg-white rounded"
          : "text-white"
      }`}>

        BIM Services

        {expertiseContent === "bim" && (
          <span className="absolute left-0 bottom-0 w-full h-[2px] bg-white"></span>
        )}

      </p>
    </div>

    {/* ENGINEERING */}
    <div
      onClick={() => setExpertiseContent("engineering")}
      className="cursor-pointer"
    >
      <p className={`px-2 py-1 text-[17px] font-medium relative transition ${
        expertiseContent === "engineering"
          ? "text-black bg-white rounded"
          : "text-white"
      }`}>

        Engineering Design

        {expertiseContent === "engineering" && (
          <span className="absolute left-0 bottom-0 w-full h-[2px] bg-white"></span>
        )}

      </p>
    </div>

    {/* DIGITAL */}
    <div
      onClick={() => setExpertiseContent("digital")}
      className="cursor-pointer"
    >
      <p className={`px-2 py-1 text-[17px] font-medium relative transition ${
        expertiseContent === "digital"
          ? "text-black bg-white rounded"
          : "text-white"
      }`}>

        Digital Construction

        {expertiseContent === "digital" && (
          <span className="absolute left-0 bottom-0 w-full h-[2px] bg-white"></span>
        )}

      </p>
    </div>

    {/* TWIN */}
    <div
      onClick={() => setExpertiseContent("twin")}
      className="cursor-pointer"
    >
      <p className={`px-2 py-1 text-[17px] font-medium relative transition ${
        expertiseContent === "twin"
          ? "text-black bg-white rounded"
          : "text-white"
      }`}>

        Digital Twin

        {expertiseContent === "twin" && (
          <span className="absolute left-0 bottom-0 w-full h-[2px] bg-white"></span>
        )}

      </p>
    </div>

    {/* CAD */}
   {/* CAD */}

<div
  onClick={() => setExpertiseContent("cad")}
  className="cursor-pointer"
>
  <div
    className={`px-3 py-2 text-[17px] font-medium rounded transition ${
      expertiseContent === "cad"
        ? "bg-white text-black font-semibold"
        : "text-white hover:bg-blue-800"
    }`}
  >
    2D CAD & Drafting
  </div>
</div> 
      

    {/* VERTICALS */}
    <div
      onClick={() => setExpertiseContent("verticals")}
      className="cursor-pointer"
    >
      <p className={`px-2 py-1 text-[17px] font-medium relative transition ${
        expertiseContent === "verticals"
          ? "text-black bg-white rounded"
          : "text-white"
      }`}>

        Verticals
   
       

      </p>
    </div>

  </div>
</div>
          {/* MIDDLE WHITE SIDE */}
         <div className="bg-white p-16 text-black w-[54%]">

  {/* TOP TITLE */}
  <div className="text-blue-900 font-semibold text-[17px] mb-6 ml-2 -mt-8">
    Service &gt;{" "}

    {expertiseContent === "bim" && "BIM Services"}
    {expertiseContent === "engineering" && "Engineering Design"}
    {expertiseContent === "digital" && "Digital Construction"}
    {expertiseContent === "twin" && "Digital Twin"}
    {expertiseContent === "cad" && "2D CAD & Drafting"}
    {expertiseContent === "verticals" && "Verticals"}

  </div>

       {expertiseContent === "bim" && (
    <div className="grid grid-cols-2 gap-y-6 gap-x-12">

      <div className="flex items-center gap-3 hover:text-blue-900 cursor-pointer">
        <i className="bi bi-box text-3xl"></i>
        <span>3D Modelling</span>
      </div>

      <div className="flex items-center gap-3 hover:text-blue-900 cursor-pointer">
        <i className="bi bi-currency-exchange text-xl"></i>
        <span>Value Engineering</span>
      </div>

      <div className="flex items-center gap-3 hover:text-blue-900 cursor-pointer">
        <i className="bi bi-building text-2xl"></i>
        <span>Digital Prefabrication</span>
      </div>

      <div className="flex items-center gap-3 hover:text-blue-900 cursor-pointer">
        <i className="bi bi-file-earmark-text text-2xl"></i>
        <span>Construction Documentation</span>
      </div>

      <div className="flex items-center gap-3 hover:text-blue-900 cursor-pointer">
        <i className="bi bi-diagram-3 text-2xl"></i>
        <span>Constructability Review</span>
      </div>

      <div className="flex items-center gap-3 hover:text-blue-900 cursor-pointer">
        <i className="bi bi-intersect text-2xl"></i>
        <span>Clash Coordination</span>
      </div>

    </div>
  )}

 {expertiseContent === "engineering" && (
  <div className="grid grid-cols-2 gap-y-6 gap-x-12">

    <div className="flex items-center gap-3 hover:text-blue-900 cursor-pointer">
      <i className="bi bi-building text-2xl"></i>
      <span>Architectural</span>
    </div>

    <div className="flex items-center gap-3 hover:text-blue-900 cursor-pointer">
      <i className="bi bi-bricks text-3xl"></i>
      <span>Structural</span>
    </div>

    <div className="flex items-center gap-3 hover:text-blue-900 cursor-pointer">
      <i className="bi bi-gear text-3xl"></i>
      <span>Mechanical Engineering Design</span>
    </div>

    <div className="flex items-center gap-3 hover:text-blue-900 cursor-pointer">
      <i className="bi bi-lightning-charge text-3xl"></i>
      <span>Electrical</span>
    </div>

    <div className="flex items-center gap-3 hover:text-blue-900 cursor-pointer">
      <i className="bi bi-fire text-3xl"></i>
      <span>Fire Protection</span>
    </div>

    <div className="flex items-center gap-3 hover:text-blue-900 cursor-pointer">
      <i className="bi bi-thermometer-sun text-3xl"></i>
      <span>Building Energy</span>
    </div>

  </div>
)}

 {expertiseContent === "digital" && (
  <div className="grid grid-cols-2 gap-y-6 gap-x-12">

    <div className="flex items-center gap-3 hover:text-blue-900 cursor-pointer">
      <i className="bi bi-megaphone text-2xl"></i>
      <span>Marketing / BID Presentations</span>
    </div>

    <div className="flex items-center gap-3 hover:text-blue-900 cursor-pointer">
      <i className="bi bi-film text-3xl"></i>
      <span>4D & 5D Construction Simulation</span>
    </div>

    <div className="flex items-center gap-3 hover:text-blue-900 cursor-pointer">
      <i className="bi bi-calculator text-3xl"></i>
      <span>Quantity Surveying</span>
    </div>

    <div className="flex items-center gap-3 hover:text-blue-900 cursor-pointer">
      <i className="bi bi-geo-alt text-3xl"></i>
      <span>GIS</span>
    </div>

    <div className="flex items-center gap-3 hover:text-blue-900 cursor-pointer">
      <i className="bi bi-cash-stack text-3xl"></i>
      <span>Pre-bid Estimation</span>
    </div>

    <div className="flex items-center gap-3 hover:text-blue-900 cursor-pointer">
      <i className="bi bi-rulers text-3xl"></i>
      <span>Laser Scanning</span>
    </div>

  </div>
)}
 {expertiseContent === "twin" && (
  <div className="grid grid-cols-2 gap-y-6 gap-x-12">

    <div className="flex items-center gap-3 hover:text-blue-900 cursor-pointer">
      <i className="bi bi-gear-wide-connected text-3xl"></i>
      <span>Implementation</span>
    </div>

    <div className="flex items-center gap-3 hover:text-blue-900 cursor-pointer">
      <i className="bi bi-database text-3xl"></i>
      <span>Data Management</span>
    </div>

    <div className="flex items-center gap-3 hover:text-blue-900 cursor-pointer">
      <i className="bi bi-activity text-3xl"></i>
      <span>Asset Monitoring</span>
    </div>

    <div className="flex items-center gap-3 hover:text-blue-900 cursor-pointer">
      <i className="bi bi-leaf text-3xl"></i>
      <span>Sustainability Applications</span>
    </div>

    <div className="flex items-center gap-3 hover:text-blue-900 cursor-pointer">
      <i className="bi bi-card-list text-3xl"></i>
      <span>COBie and Asset Register</span>
    </div>

    <div className="flex items-center gap-3 hover:text-blue-900 cursor-pointer">
      <i className="bi bi-camera-reels text-3xl"></i>
      <span>Scan to BIM</span>
    </div>

  </div>
)}


{expertiseContent === "cad" && (
  <div className="grid grid-cols-2 gap-y-6 gap-x-12">

    {/* PDF to CAD */}
    <div className="flex items-center gap-3 hover:text-blue-900 cursor-pointer transition">
      <i className="bi bi-file-earmark-pdf text-3xl"></i>
      <span>PDF to CAD Conversion</span>
    </div>

    {/* Indexing */}
    <div className="flex items-center gap-3 hover:text-blue-900 cursor-pointer transition">
      <i className="bi bi-tags text-3xl"></i>
      <span>Indexing & Renaming</span>
    </div>

    {/* Redline */}
    <div className="flex items-center gap-3 hover:text-blue-900 cursor-pointer transition">
      <i className="bi bi-pencil-square text-3xl"></i>
      <span>Redline Mark-ups / As-Built</span>
    </div>

    {/* Landscaping */}
    <div className="flex items-center gap-3 hover:text-blue-900 cursor-pointer transition">
      <i className="bi bi-tree text-3xl"></i>
      <span>Landscaping & Pool Design Assistance</span>
    </div>

    {/* Shop Drawing */}
    <div className="flex items-center gap-3 hover:text-blue-900 cursor-pointer transition">
      <i className="bi bi-rulers text-3xl"></i>
      <span>Shop Drawing (Inventor / SolidWorks)</span>
    </div>

  </div>
)} 


{expertiseContent === "verticals" && (
  <div className="grid grid-cols-2 gap-y-6 gap-x-12">

    {/* Airport */}
    <div className="flex items-center gap-3 hover:text-blue-900 cursor-pointer transition">
      <i className="bi bi-airplane text-3xl"></i>
      <span>Airport</span>
    </div>

    {/* Data Centre */}
    <div className="flex items-center gap-3 hover:text-blue-900 cursor-pointer transition">
      <i className="bi bi-hdd-network text-3xl"></i>
      <span>Data Centre</span>
    </div>

    {/* Stadium */}
    <div className="flex items-center gap-3 hover:text-blue-900 cursor-pointer transition">
      <i className="bi bi-trophy text-3xl"></i>
      <span>Stadium</span>
    </div>

    {/* Semiconductor */}
    <div className="flex items-center gap-3 hover:text-blue-900 cursor-pointer transition">
      <i className="bi bi-cpu text-3xl"></i>
      <span>Semiconductor</span>
    </div>

    {/* Industrial */}
    <div className="flex items-center gap-3 hover:text-blue-900 cursor-pointer transition">
      <i className="bi bi-building-gear text-3xl"></i>
      <span>Industrial</span>
    </div>

    {/* Infrastructure */}
    <div className="flex items-center gap-3 hover:text-blue-900 cursor-pointer transition">
      <i className="bi bi-buildings text-3xl"></i>
      <span>Infrastructure</span>
    </div>

    {/* Rail & Road */}
    <div className="flex items-center gap-3 hover:text-blue-900 cursor-pointer transition">
      <i className="bi bi-train-front text-3xl"></i>
      <span>Rail & Road</span>
    </div>

    {/* Healthcare */}
    <div className="flex items-center gap-3 hover:text-blue-900 cursor-pointer transition">
      <i className="bi bi-hospital text-3xl"></i>
      <span>Healthcare</span>
    </div>

  </div>
)}

</div>

          {/* RIGHT GREY SIDE */}
        {/* RIGHT GREY SIDE */}
{/* RIGHT GREY SIDE */}
<div className="bg-gray-200 p-8 w-[38%]">

  <div className="grid grid-cols-2 gap-x-8">

    {/* LEFT COLUMN */}
    <div>

      <h3 className="text-[17px] font-semibold text-black mb-5">
        Consulting
      </h3>

      <div className="space-y-4 text-[14px] font-medium text-gray-800">

        <div className="flex items-center gap-2 hover:text-black cursor-pointer transition leading-tight">
          <i className="bi bi-mortarboard-fill text-sky-600 text-lg"></i>
          <span>Training</span>
        </div>

        <div className="flex items-center gap-2 hover:text-black cursor-pointer transition leading-tight">
          <i className="bi bi-cpu-fill text-sky-600 text-lg"></i>
          <span>Automation</span>
        </div>

        <div className="flex items-center gap-2 hover:text-black cursor-pointer transition leading-tight">
          <i className="bi bi-grid-1x2-fill text-sky-600 text-lg"></i>
          <span>BIM Template & Content Creation</span>
        </div>

        <div className="flex items-center gap-2 hover:text-black cursor-pointer transition leading-tight">
          <i className="bi bi-diagram-3-fill text-sky-600 text-lg"></i>
          <span>BIM Execution Plan</span>
        </div>

        <div className="flex items-center gap-2 hover:text-black cursor-pointer transition leading-tight">
          <i className="bi bi-kanban-fill text-sky-600 text-lg"></i>
          <span>BIM Management</span>
        </div>

        <div className="flex items-center gap-2 hover:text-black cursor-pointer transition leading-tight">
          <i className="bi bi-patch-check-fill text-sky-600 text-lg"></i>
          <span>ISO 19650</span>
        </div>

      </div>

    </div>

    {/* RIGHT COLUMN */}
    {/* RIGHT COLUMN */}
<div>

  <h3 className="text-[17px] font-semibold text-black mb-5">
    Clients
  </h3>

  <div className="space-y-4 text-[14px] font-medium text-gray-800">

    <div className="flex items-center gap-2 hover:text-black cursor-pointer transition leading-tight">
      <i className="bi bi-building-fill text-sky-600 text-lg"></i>
      <span>Architects</span>
    </div>

    <div className="flex items-center gap-2 hover:text-black cursor-pointer transition leading-tight">
      <i className="bi bi-gear-fill text-sky-600 text-lg"></i>
      <span>Engineers</span>
    </div>

    <div className="flex items-center gap-2 hover:text-black cursor-pointer transition leading-tight">
      <i className="bi bi-hammer text-sky-600 text-lg"></i>
      <span>Contractors</span>
    </div>

    <div className="flex items-center gap-2 hover:text-black cursor-pointer transition leading-tight">
      <i className="bi bi-person-badge-fill text-sky-600 text-lg"></i>
      <span>Owners</span>
    </div>

  </div>

  {/* AUTODESK HEADING */}
  <h3 className="text-[17px] font-semibold text-black mt-7 mb-5">
    Autodesk Solution
  </h3>

  <div className="space-y-4 text-[14px] font-medium text-gray-800">

    <div className="flex items-center gap-2 hover:text-black cursor-pointer transition leading-tight">
      <i className="bi bi-shop text-sky-600 text-lg"></i>
      <span>Autodesk Reseller</span>
    </div>

    <div className="flex items-center gap-2 hover:text-black cursor-pointer transition leading-tight">
      <i className="bi bi-journal-bookmark-fill text-sky-600 text-lg"></i>
      <span>Autodesk Training Center</span>
    </div>

  </div>

</div>
        </div>

      </div>

    </div>

  </div>

</div>



)} 

</div> {/* relative z-50 */}

          {/* PORTFOLIO */}
          <div className="relative z-50">

            <div
              onClick={() =>
                setOpenMenu(openMenu === "portfolio" ? null : "portfolio")
              }
              className="cursor-pointer flex items-center gap-1"
            >
              <span className="hover:text-blue-900">Portfolio</span>

              <svg width="12" height="12" viewBox="0 0 24 24" fill="none"
                stroke="currentColor" strokeWidth="2">
                <polyline points="6 9 12 15 18 9" />
              </svg>
            </div>

            {openMenu === "portfolio" && (
              <div className="absolute top-8 left-0 flex flex-col bg-gray-100 shadow-lg rounded-lg p-4 w-48 z-50">

                <span className="text-black py-1 hover:text-blue-900">Projects</span>
                <span className="text-black py-1 hover:text-blue-900">Case Studies</span>
                <span className="text-black py-1 hover:text-blue-900">Clients</span>

              </div>
            )}

          </div>

          {/* RESOURCES */}
          <div className="relative z-50">

            <div
              onClick={() =>
                setOpenMenu(openMenu === "resources" ? null : "resources")
              }
              className="cursor-pointer flex items-center gap-1"
            >
              <span className="hover:text-blue-900">Resources</span>

              <svg width="12" height="12" viewBox="0 0 24 24" fill="none"
                stroke="currentColor" strokeWidth="2">
                <polyline points="6 9 12 15 18 9" />
              </svg>
            </div>

            {openMenu === "resources" && (
              <div className="absolute top-8 left-0 flex flex-col bg-gray-100 shadow-lg rounded-lg p-4 w-48 z-50">

                <span className="text-black py-1 hover:text-blue-900">Blogs</span>
                <span className="text-black py-1 hover:text-blue-900">Guides</span>
                <span className="text-black py-1 hover:text-blue-900">Downloads</span>

              </div>
            )}

          </div>

          {/* EVENTS */}
          <Link href="/events">
            <div className={`cursor-pointer transition ${
              pathname === "/events"
                ? "text-yellow-400"
                : "hover:text-blue-900"
            }`}>
              <span>Events & TradeShows</span>
            </div>
          </Link>

          {/* CAREER */}
          <div className="relative z-50">

            <div
              onClick={() =>
                setOpenMenu(openMenu === "career" ? null : "career")
              }
              className="cursor-pointer flex items-center gap-1"
            >
              <span className="hover:text-blue-900">Career</span>

              <svg width="12" height="12" viewBox="0 0 24 24" fill="none"
                stroke="currentColor" strokeWidth="2">
                <polyline points="6 9 12 15 18 9" />
              </svg>
            </div>

            {openMenu === "career" && (
              <div className="absolute top-8 left-0 flex flex-col bg-gray-100 shadow-lg rounded-lg p-4 w-48 z-50">

                <span className="text-black py-1 hover:text-blue-900">Open Positions</span>
                <span className="text-black py-1 hover:text-blue-900">Life at Company</span>
                <span className="text-black py-1 hover:text-blue-900">Internships</span>
                <span className="text-black py-1 hover:text-blue-900">Hiring Process</span>
                <span className="text-black py-1 hover:text-blue-900">Apply Now</span>

              </div>
            )}

          </div>

          {/* BLOG */}
          <Link href="/blog">
            <div className={`cursor-pointer transition ${
              pathname === "/blog"
                ? "text-yellow-400"
                : "hover:text-blue-900"
            }`}>
              <span>Blog</span>
            </div>
          </Link>

        </div>

        {/* RIGHT SIDE */}
        <div className="absolute right-10 flex items-center gap-4 z-50">

          <i className="bi bi-search text-[20px] cursor-pointer hover:text-blue-900"></i>

          <span className="font-semibold cursor-pointer hover:text-blue-900">
            Login
          </span>

       <button className="bg-amber-500 text-black px-6 py-2 rounded-lg font-semibold hover:bg-amber-600 transition duration-300 shadow-md">
  Get in Touch
</button>
        </div>

      </div>
    </div>
  );
}